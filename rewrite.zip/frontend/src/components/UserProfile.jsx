// frontend/src/components/UserProfile.jsx

function UserProfile() {
  return <div>UserProfile</div>;
}

export default UserProfile;